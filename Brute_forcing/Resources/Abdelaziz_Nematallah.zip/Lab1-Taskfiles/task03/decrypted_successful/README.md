Well Done!

You have successfully decrypted the zip file :-)
